package com.kumaran.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kumaran.Persistent.Admin;

public interface AdminRepository extends JpaRepository<Admin, String>{

}
