package com.kumaran.repositories;

import com.kumaran.Persistent.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, String>{

}
