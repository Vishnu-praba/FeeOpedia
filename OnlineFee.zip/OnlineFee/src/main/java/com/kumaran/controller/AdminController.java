package com.kumaran.controller;

import java.util.Arrays;
import java.util.List;
import javax.validation.Valid;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.kumaran.Persistent.Admin;
import com.kumaran.Persistent.Student;
import com.kumaran.services.AdminService;
import com.kumaran.services.StudentService;

@Controller
public class AdminController {
	
	//Home Admin button

	
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("/home")
	public String home() {
		System.out.println("Start page ->");
		return "home";
	}
	
	@RequestMapping("/Admin")
	public String AdminLogin() {
		System.out.println("Going to Admin Login..");
		return "adminlogin";
	}
	
	@PostMapping("/adminDashboard")
	public String Admindashboard(@RequestParam String userName,@RequestParam String password,Model mv) {
		Admin login=adminService.get(userName);
		if(login.getUserName().equals("admin") && login.getPassword().equals("Admin123!"))
		{
			
				List<Student> studentList= studentService.find();
				mv.addAttribute("studentList",studentList);
				System.out.println(studentList);
				List<String> payNotPay = Arrays.asList("NotPaid","Paid");
				mv.addAttribute("payNotPay", payNotPay);
				for(Student stu:studentList) {
				System.out.println(stu);
				}
			
				return "admindashboard";
			}
		
			
			
		
		else
			//mv.addObject("ErrorMessage","Please Enter Valid USERNAME or PASSWORD");
			return "adminlogin";
	}
	
	/*
	 * @PostMapping("/adminDashboard") public ModelAndView
	 * goToAdminDashboard(@ModelAttribute("LoginData")Admin login) { ModelAndView
	 * mv= new ModelAndView("admindashboard");
	 * System.out.println(login.getUserName());
	 * System.out.println(login.getPassword());
	 * if(login.getUserName().equals("admin") &&
	 * login.getPassword().equals("Admin123!")) { List<Student> studentList=
	 * studentservice.find();
	 * 
	 * 
	 * 
	 * mv.addObject("studentList",studentList); System.out.println(studentList);
	 * List<String> payNotPay = Arrays.asList("NotPaid","Paid");
	 * mv.addObject("payNotPay", payNotPay); for(Student stu:studentList) {
	 * System.out.println(stu); }
	 * 
	 * return mv; }
	 * 
	 * else
	 * //mv.addObject("ErrorMessage","Please Enter Valid USERNAME or PASSWORD");
	 * return new
	 * ModelAndView("AdminLogin","err","!!Please Enter Valid USERNAME or PASSWORD");
	 * 
	 * }
	 */
	//adding student
	
	@GetMapping("/addStudent")
	public String AddStudent(Model model) {

	Student student=new Student();
	List<String> payNotPay = Arrays.asList("NotPaid","Paid");
	model.addAttribute("student", student);
	model.addAttribute("payNotPay", payNotPay);
	
	return "addstudent";
	}

	@PostMapping("/addStudentResult")
	public String AddStudentResult(@Valid @ModelAttribute("student")Student student,BindingResult br,Model m){

	if(br.hasErrors()) {
		
		List<String> payNotPay = Arrays.asList("NotPaid","Paid");
		m.addAttribute("payNotPay", payNotPay);
		System.out.println(br);
		return "addstudent";


	}
	//System.out.println(student.getPaidFee());
	studentService.insertDetails(student);
	return "redirect:/viewStudent";	
	
	}
	//show student is added
	
	//show the records in db
	
	//edit
	
	@RequestMapping("/edit")
	public String edit(@RequestParam String id,Model m) {
		List<String> payNotPay = Arrays.asList("NotPaid","Paid");
		m.addAttribute("payNotPay", payNotPay);
		Student student = studentService.get(id);
		m.addAttribute("student", student);
		
		return "editstudent";
	}
	
	//delete 
	@RequestMapping("/delete")
	public String delete(@RequestParam String id) {
		studentService.delete(id);
		return "redirect:/viewStudent";		
	}
	@RequestMapping("/viewStudent")
	public String viewStudent(Model m)
	{
		 List<Student> list=studentService.find();    
		 m.addAttribute("studentList",list);  
		 return "admindashboard";  
	}
	
	  //logout
	  
	  @GetMapping("/logout") public String doLogout(HttpSession session,Model
	  model) {
	  
	  session.invalidate();
	  return "home"; 
	  }
	  
	  
	 
}

