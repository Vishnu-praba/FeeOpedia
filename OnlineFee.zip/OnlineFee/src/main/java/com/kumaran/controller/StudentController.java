package com.kumaran.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.kumaran.Persistent.Admin;
import com.kumaran.Persistent.Student;

import com.kumaran.services.VerificationResult;
import com.kumaran.services.PhoneVerificationService;
import com.kumaran.services.StudentService;
@Controller
public class StudentController {
	
	
		@Autowired
		StudentService service;
		
		@Autowired
		PhoneVerificationService phonesmsservice;

		/*
		 * @RequestMapping("/home") public String home() {
		 * System.out.println("Going home..."); return "home"; }
		 */
		@RequestMapping("/Student")
		public String login() {
			
			return "login";
			
		}
		@GetMapping("/studentlogin")
		public String loginPage(@RequestParam String id,@RequestParam String date,Model m)
		{
			Student student = service.get(id);
			if(date.equals(student.getDob()))
			{
			List<String> payNotPay = Arrays.asList("NotPaid","Paid");
			m.addAttribute("payNotPay", payNotPay);
			m.addAttribute("student",student);
			return "details";
		    }
			else {
				return "login";
			}
		}
		
		@PostMapping("/pay")
		public String pay(@Valid @ModelAttribute("student") Student student,BindingResult bindingResult,Model model,HttpServletRequest request,HttpServletResponse response) throws IOException {
			response.setContentType("text/css");
			if(student.getPaidFee()>student.getRemainingFee())
			{
				return "redirect:/Student";
			}
			if(student.getRemainingFee()!=0)
			{
				service.insertDetails(student);
				model.addAttribute("Student",student);
				return "PayPage";
			}
			else
			{
	
				PrintWriter pw=response.getWriter();
				pw.println("alert('Already Paid')");
				return "redirect:/Student";
			}
		}
		
		
		
		@PostMapping("/sendotp")
		public ResponseEntity<String> sendotp(@RequestParam("phone") String phone)
		{
		    VerificationResult result=phonesmsservice.startVerification(phone);
		    if(result.isValid())
		    {
		    	return new ResponseEntity<>("Otp Sent..",HttpStatus.OK);
		    }
			return new ResponseEntity<>("Otp failed to sent..",HttpStatus.BAD_REQUEST);
		}
		
		@PostMapping("/verifyotp")
		public String sendotp(@RequestParam("phone") String phone, @RequestParam("otp") String otp,@RequestParam("id") String id)
		{
		   VerificationResult result=phonesmsservice.checkverification(phone,otp);
		    if(result.isValid())
		    {
		    	Student student=service.get(id);
		    	student.setRemainingFee(student.getRemainingFee()-student.getPaidFee());
				if(student.getRemainingFee()==0 || student.getRemainingFee()<0)
					student.setPayment_status("Paid");
				int pFee=student.getTutionFee()+student.getHostelFee();
				student.setPaidFee(pFee-student.getRemainingFee());
				service.insertDetails(student);
		    	return "success";
		    }
		    else
		    {
		    	Student student=service.get(id);
		    	int tFee=student.getHostelFee()+student.getTutionFee();
		    	int pFee=student.getRemainingFee()-tFee;
		    	student.setPaidFee(pFee);
		    	service.insertDetails(student);
		    	return "fail";
		    }
		}
		
		
		  @GetMapping("/logoutStudent") public String doLogout(HttpSession
		  session,Model model) {
		  
		  session.invalidate(); 
		  return "home"; }
		 

}
