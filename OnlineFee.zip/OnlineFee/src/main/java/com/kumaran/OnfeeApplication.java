package com.kumaran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnfeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnfeeApplication.class, args);
	}

}
