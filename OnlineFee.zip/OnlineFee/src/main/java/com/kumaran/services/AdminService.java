package com.kumaran.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kumaran.Persistent.Admin;
import com.kumaran.repositories.AdminRepository;

@Service
public class AdminService {
	@Autowired
	AdminRepository repo;
	public Admin get(String userName) {
		return repo.findById(userName).get();
	}

}
