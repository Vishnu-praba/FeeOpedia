package com.kumaran.services;

import com.kumaran.repositories.StudentRepository;
import com.kumaran.Persistent.Student;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService{
	@Autowired
	StudentRepository repo;
	public List<Student> find()
	{
		return repo.findAll();
	}
	public void insertDetails(Student u)
	{
		repo.save(u);
	}
	public Student get(String id) {
		return repo.findById(id).get();
	}
	
	public void delete(String id) {
		repo.deleteById(id);
	}

}
