package com.kumaran.Persistent;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;




@Entity
public class Student {

	@Id
	private String id;
	
	@NotBlank
	private String name;
	
	@NotBlank
	private String dob;
	
	@NotBlank
	private String mobileNumber;
	
	private int tutionFee;
	
	private int hostelFee;
	
	private int paidFee;
	
	private int remainingFee;
	
	
	private String payment_status;

	
	public int getRemainingFee() {
		return remainingFee;
	}

	public void setRemainingFee(int remainingFee) {
		this.remainingFee = remainingFee;
	}
	
	public int getPaidFee() {
		return paidFee;
	}

	public void setPaidFee(int paidFee) {
		this.paidFee = paidFee;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getTutionFee() {
		return tutionFee;
	}

	public void setTutionFee(int tutionFee) {
		this.tutionFee = tutionFee;
	}

	public int getHostelFee() {
		return hostelFee;
	}

	public void setHostelFee(int hostelFee) {
		this.hostelFee = hostelFee;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}
	
	
	
}
