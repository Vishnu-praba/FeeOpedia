package com.kumaran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnfeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
